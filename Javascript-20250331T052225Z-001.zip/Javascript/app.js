console.log('Witaj w świecie JavaScript!');
console.log(typeof(42));
console.log(typeof('Hello'));
console.log(typeof(true));

console.log(5 + '10');

const name = 'cwel'
const age = 12
const isStudnt = true;

const colors  = ['blue', 'red','green']

const person = {
    name: 'Sebna',
    age: 12,
    isEmployed: true
}

const data = null;
console.log(typeof(data));

console.log(2/0);

var a = 5;
a = 6
console.log(a);

// const language = 'Javascript'
// language = 'PHP'
// console.log(language);

const table = []
table.push('szymon')
console.log(table);



let liczba = -2;

// if(liczba % 2 ===0)
// {
//     console.log('liczba parzysta');
// }else
// {
//     console.log('nie');
// }
if(liczba > 0)
{
    console.log('Dodatnia');
}
else if(liczba == 0 )
{
    console.log('zero');
}else
{
    console.log('minues');
}

// let sum=0
// for (let i = 1; i <= 100; i++) {
//     sum +=  i
//     console.log(sum);
    
// }
// let suma = 0;
// for (let i = 1; i <= 100; i++) {
//     suma += i;
// }
// console.log(suma);

const number = parseInt(prompt('Podaj liczbe'))

// if(number / 1 && number / number)
// {
//     console.log('liczba pierwsza');
// }
// else
// {
//     console.log('Liczb nie pierwsza');
// }
let c = 0;
for (let i = 1; i <= number; i++) {
    
    if(number % i === 0)
    {
        c += 1
    }
    
}
if(c === 2)
{
    console.log('liczba pierwsza');
}else
{
    console.log('Nie');
}