const name = document.querySelector(".name");
const surName = document.querySelector(".surName");
const age = document.querySelector(".age");
const mail = document.querySelector(".mail");

function formSend() {
  if (
    name.value === "" ||
    surName.value === "" ||
    age.value === "" ||
    mail.value === ""
  ) {
    document.querySelector(".result").innerHTML = "Uzupełnij wszystkie pola!";
  } else {
    if (age.value >= 18) {
      document.querySelector(".result").innerHTML = `Imię: ${name.value} <br>
        Nazwisko: ${surName.value} <br>
        Wiek: ${age.value} <br>
        Mail: ${mail.value} <br>
        Jesteś pełnoletni`;
    } else {
      document.querySelector(".result").innerHTML = `Imię: ${name.value} <br>
        Nazwisko: ${surName.value} <br>
        Wiek: ${age.value} <br>
        Mail: ${mail.value} <br>
        Jesteś niepełnoletni`;
    }
  }
}
