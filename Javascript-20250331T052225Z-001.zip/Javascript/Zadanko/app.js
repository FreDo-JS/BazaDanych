const product = document.querySelector(".productImg");
const items = document.querySelectorAll(".item");
const photos = document.querySelectorAll(".photo");

photos.forEach((photo) => {
  photo.addEventListener("click", () => {
    product.src = photo.src;
  });
});
////////////////////////

const quantity = document.querySelector(".cwel");
const minus = document.querySelector(".minus");
const plus = document.querySelector(".plus");

let quanti = 0;

plus.addEventListener("click", () => {
  quanti++;
  quantity.textContent = quanti;
});

minus.addEventListener("click", () => {
  if (quanti > 0) {
    quanti--;
    quantity.textContent = quanti;
  }
});

/////////////////////////
const cartBtn = document.querySelector(".cartButton");
const cartBox = document.querySelector(".cartBox");
const addCart = document.querySelector(".addToCart");

cartBtn.addEventListener("click", () => {
  cartBox.classList.toggle("active");
});

addCart.addEventListener("click", () => {
  const existItem = document.querySelector(".createdItem");

  let price = 125.0;
  if (!existItem) {
    const newItem = document.createElement("div");
    newItem.classList.add("createdItem");
    newItem.innerHTML = `<p>Twoje buty</p>
    <p>Ilość: ${quanti} x ${price}</p>
    <p>Łączna Kwota ${quanti * price}</p>
    `;

    cartBox.appendChild(newItem);
  } else {
    existItem.innerHTML = `<p>Twoje buty</p>
    <p>Ilość: ${quanti} x ${price}</p>
    <p>Łączna Kwota ${quanti * price}</p>
    `;
  }
});
